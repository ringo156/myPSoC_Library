/*******************************************************************************
* File Name: emFile_SCB_SPI_0_SPI_UART_PVT.h
* Version 3.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_emFile_SCB_SPI_0_H)
#define CY_SCB_SPI_UART_PVT_emFile_SCB_SPI_0_H

#include "emFile_SCB_SPI_0_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if (emFile_SCB_SPI_0_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  emFile_SCB_SPI_0_rxBufferHead;
    extern volatile uint32  emFile_SCB_SPI_0_rxBufferTail;
    extern volatile uint8   emFile_SCB_SPI_0_rxBufferOverflow;
#endif /* (emFile_SCB_SPI_0_INTERNAL_RX_SW_BUFFER_CONST) */

#if (emFile_SCB_SPI_0_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  emFile_SCB_SPI_0_txBufferHead;
    extern volatile uint32  emFile_SCB_SPI_0_txBufferTail;
#endif /* (emFile_SCB_SPI_0_INTERNAL_TX_SW_BUFFER_CONST) */

#if (emFile_SCB_SPI_0_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 emFile_SCB_SPI_0_rxBufferInternal[emFile_SCB_SPI_0_INTERNAL_RX_BUFFER_SIZE];
#endif /* (emFile_SCB_SPI_0_INTERNAL_RX_SW_BUFFER) */

#if (emFile_SCB_SPI_0_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 emFile_SCB_SPI_0_txBufferInternal[emFile_SCB_SPI_0_TX_BUFFER_SIZE];
#endif /* (emFile_SCB_SPI_0_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

void emFile_SCB_SPI_0_SpiPostEnable(void);
void emFile_SCB_SPI_0_SpiStop(void);

#if (emFile_SCB_SPI_0_SCB_MODE_SPI_CONST_CFG)
    void emFile_SCB_SPI_0_SpiInit(void);
#endif /* (emFile_SCB_SPI_0_SCB_MODE_SPI_CONST_CFG) */

#if (emFile_SCB_SPI_0_SPI_WAKE_ENABLE_CONST)
    void emFile_SCB_SPI_0_SpiSaveConfig(void);
    void emFile_SCB_SPI_0_SpiRestoreConfig(void);
#endif /* (emFile_SCB_SPI_0_SPI_WAKE_ENABLE_CONST) */

void emFile_SCB_SPI_0_UartPostEnable(void);
void emFile_SCB_SPI_0_UartStop(void);

#if (emFile_SCB_SPI_0_SCB_MODE_UART_CONST_CFG)
    void emFile_SCB_SPI_0_UartInit(void);
#endif /* (emFile_SCB_SPI_0_SCB_MODE_UART_CONST_CFG) */

#if (emFile_SCB_SPI_0_UART_WAKE_ENABLE_CONST)
    void emFile_SCB_SPI_0_UartSaveConfig(void);
    void emFile_SCB_SPI_0_UartRestoreConfig(void);
#endif /* (emFile_SCB_SPI_0_UART_WAKE_ENABLE_CONST) */


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in emFile_SCB_SPI_0_SetPins() */
#define emFile_SCB_SPI_0_UART_RX_PIN_ENABLE    (emFile_SCB_SPI_0_UART_RX)
#define emFile_SCB_SPI_0_UART_TX_PIN_ENABLE    (emFile_SCB_SPI_0_UART_TX)

/* UART RTS and CTS position to be used in  emFile_SCB_SPI_0_SetPins() */
#define emFile_SCB_SPI_0_UART_RTS_PIN_ENABLE    (0x10u)
#define emFile_SCB_SPI_0_UART_CTS_PIN_ENABLE    (0x20u)


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Interrupt processing */
#define emFile_SCB_SPI_0_SpiUartEnableIntRx(intSourceMask)  emFile_SCB_SPI_0_SetRxInterruptMode(intSourceMask)
#define emFile_SCB_SPI_0_SpiUartEnableIntTx(intSourceMask)  emFile_SCB_SPI_0_SetTxInterruptMode(intSourceMask)
uint32  emFile_SCB_SPI_0_SpiUartDisableIntRx(void);
uint32  emFile_SCB_SPI_0_SpiUartDisableIntTx(void);


#endif /* (CY_SCB_SPI_UART_PVT_emFile_SCB_SPI_0_H) */


/* [] END OF FILE */
