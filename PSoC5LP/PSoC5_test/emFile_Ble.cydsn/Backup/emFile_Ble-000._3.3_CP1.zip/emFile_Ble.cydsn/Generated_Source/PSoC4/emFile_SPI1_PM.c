/*******************************************************************************
* File Name: emFile_SPI1_PM.c
* Version 3.0
*
* Description:
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "emFile_SPI1.h"
#include "emFile_SPI1_PVT.h"

#if(emFile_SPI1_SCB_MODE_I2C_INC)
    #include "emFile_SPI1_I2C_PVT.h"
#endif /* (emFile_SPI1_SCB_MODE_I2C_INC) */

#if(emFile_SPI1_SCB_MODE_EZI2C_INC)
    #include "emFile_SPI1_EZI2C_PVT.h"
#endif /* (emFile_SPI1_SCB_MODE_EZI2C_INC) */

#if(emFile_SPI1_SCB_MODE_SPI_INC || emFile_SPI1_SCB_MODE_UART_INC)
    #include "emFile_SPI1_SPI_UART_PVT.h"
#endif /* (emFile_SPI1_SCB_MODE_SPI_INC || emFile_SPI1_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG || \
   (emFile_SPI1_SCB_MODE_I2C_CONST_CFG   && (!emFile_SPI1_I2C_WAKE_ENABLE_CONST))   || \
   (emFile_SPI1_SCB_MODE_EZI2C_CONST_CFG && (!emFile_SPI1_EZI2C_WAKE_ENABLE_CONST)) || \
   (emFile_SPI1_SCB_MODE_SPI_CONST_CFG   && (!emFile_SPI1_SPI_WAKE_ENABLE_CONST))   || \
   (emFile_SPI1_SCB_MODE_UART_CONST_CFG  && (!emFile_SPI1_UART_WAKE_ENABLE_CONST)))

    emFile_SPI1_BACKUP_STRUCT emFile_SPI1_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: emFile_SPI1_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component to enter Deep Sleep.
*  The "Enable wakeup from Sleep Mode" selection has an influence on
*  this function implementation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void emFile_SPI1_Sleep(void)
{
#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG)

    if(emFile_SPI1_SCB_WAKE_ENABLE_CHECK)
    {
        if(emFile_SPI1_SCB_MODE_I2C_RUNTM_CFG)
        {
            emFile_SPI1_I2CSaveConfig();
        }
        else if(emFile_SPI1_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            emFile_SPI1_EzI2CSaveConfig();
        }
    #if(!emFile_SPI1_CY_SCBIP_V1)
        else if(emFile_SPI1_SCB_MODE_SPI_RUNTM_CFG)
        {
            emFile_SPI1_SpiSaveConfig();
        }
        else if(emFile_SPI1_SCB_MODE_UART_RUNTM_CFG)
        {
            emFile_SPI1_UartSaveConfig();
        }
    #endif /* (!emFile_SPI1_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        emFile_SPI1_backup.enableState = (uint8) emFile_SPI1_GET_CTRL_ENABLED;

        if(0u != emFile_SPI1_backup.enableState)
        {
            emFile_SPI1_Stop();
        }
    }

#else

    #if (emFile_SPI1_SCB_MODE_I2C_CONST_CFG && emFile_SPI1_I2C_WAKE_ENABLE_CONST)
        emFile_SPI1_I2CSaveConfig();

    #elif (emFile_SPI1_SCB_MODE_EZI2C_CONST_CFG && emFile_SPI1_EZI2C_WAKE_ENABLE_CONST)
        emFile_SPI1_EzI2CSaveConfig();

    #elif (emFile_SPI1_SCB_MODE_SPI_CONST_CFG && emFile_SPI1_SPI_WAKE_ENABLE_CONST)
        emFile_SPI1_SpiSaveConfig();

    #elif (emFile_SPI1_SCB_MODE_UART_CONST_CFG && emFile_SPI1_UART_WAKE_ENABLE_CONST)
        emFile_SPI1_UartSaveConfig();

    #else

        emFile_SPI1_backup.enableState = (uint8) emFile_SPI1_GET_CTRL_ENABLED;

        if(0u != emFile_SPI1_backup.enableState)
        {
            emFile_SPI1_Stop();
        }

    #endif /* defined (emFile_SPI1_SCB_MODE_I2C_CONST_CFG) && (emFile_SPI1_I2C_WAKE_ENABLE_CONST) */

#endif /* (emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: emFile_SPI1_Wakeup
********************************************************************************
*
* Summary:
*  Prepares the component for the Active mode operation after exiting
*  Deep Sleep. The "Enable wakeup from Sleep Mode" option has an influence
*  on this function implementation.
*  This function should not be called after exiting Sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void emFile_SPI1_Wakeup(void)
{
#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG)

    if(emFile_SPI1_SCB_WAKE_ENABLE_CHECK)
    {
        if(emFile_SPI1_SCB_MODE_I2C_RUNTM_CFG)
        {
            emFile_SPI1_I2CRestoreConfig();
        }
        else if(emFile_SPI1_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            emFile_SPI1_EzI2CRestoreConfig();
        }
    #if(!emFile_SPI1_CY_SCBIP_V1)
        else if(emFile_SPI1_SCB_MODE_SPI_RUNTM_CFG)
        {
            emFile_SPI1_SpiRestoreConfig();
        }
        else if(emFile_SPI1_SCB_MODE_UART_RUNTM_CFG)
        {
            emFile_SPI1_UartRestoreConfig();
        }
    #endif /* (!emFile_SPI1_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != emFile_SPI1_backup.enableState)
        {
            emFile_SPI1_Enable();
        }
    }

#else

    #if (emFile_SPI1_SCB_MODE_I2C_CONST_CFG  && emFile_SPI1_I2C_WAKE_ENABLE_CONST)
        emFile_SPI1_I2CRestoreConfig();

    #elif (emFile_SPI1_SCB_MODE_EZI2C_CONST_CFG && emFile_SPI1_EZI2C_WAKE_ENABLE_CONST)
        emFile_SPI1_EzI2CRestoreConfig();

    #elif (emFile_SPI1_SCB_MODE_SPI_CONST_CFG && emFile_SPI1_SPI_WAKE_ENABLE_CONST)
        emFile_SPI1_SpiRestoreConfig();

    #elif (emFile_SPI1_SCB_MODE_UART_CONST_CFG && emFile_SPI1_UART_WAKE_ENABLE_CONST)
        emFile_SPI1_UartRestoreConfig();

    #else

        if(0u != emFile_SPI1_backup.enableState)
        {
            emFile_SPI1_Enable();
        }

    #endif /* (emFile_SPI1_I2C_WAKE_ENABLE_CONST) */

#endif /* (emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */
