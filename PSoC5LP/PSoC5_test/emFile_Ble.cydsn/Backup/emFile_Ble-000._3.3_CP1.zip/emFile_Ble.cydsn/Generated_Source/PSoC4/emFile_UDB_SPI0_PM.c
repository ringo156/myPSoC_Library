/*******************************************************************************
* File Name: emFile_UDB_SPI0_PM.c
* Version 2.50
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "emFile_UDB_SPI0_PVT.h"

static emFile_UDB_SPI0_BACKUP_STRUCT emFile_UDB_SPI0_backup =
{
    emFile_UDB_SPI0_DISABLED,
    emFile_UDB_SPI0_BITCTR_INIT,
};


/*******************************************************************************
* Function Name: emFile_UDB_SPI0_SaveConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void emFile_UDB_SPI0_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: emFile_UDB_SPI0_RestoreConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void emFile_UDB_SPI0_RestoreConfig(void) 
{

}


/*******************************************************************************
* Function Name: emFile_UDB_SPI0_Sleep
********************************************************************************
*
* Summary:
*  Prepare SPIM Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  emFile_UDB_SPI0_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void emFile_UDB_SPI0_Sleep(void) 
{
    /* Save components enable state */
    emFile_UDB_SPI0_backup.enableState = ((uint8) emFile_UDB_SPI0_IS_ENABLED);

    emFile_UDB_SPI0_Stop();
}


/*******************************************************************************
* Function Name: emFile_UDB_SPI0_Wakeup
********************************************************************************
*
* Summary:
*  Prepare SPIM Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  emFile_UDB_SPI0_backup - used when non-retention registers are restored.
*  emFile_UDB_SPI0_txBufferWrite - modified every function call - resets to
*  zero.
*  emFile_UDB_SPI0_txBufferRead - modified every function call - resets to
*  zero.
*  emFile_UDB_SPI0_rxBufferWrite - modified every function call - resets to
*  zero.
*  emFile_UDB_SPI0_rxBufferRead - modified every function call - resets to
*  zero.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void emFile_UDB_SPI0_Wakeup(void) 
{
    #if(emFile_UDB_SPI0_RX_SOFTWARE_BUF_ENABLED)
        emFile_UDB_SPI0_rxBufferFull  = 0u;
        emFile_UDB_SPI0_rxBufferRead  = 0u;
        emFile_UDB_SPI0_rxBufferWrite = 0u;
    #endif /* (emFile_UDB_SPI0_RX_SOFTWARE_BUF_ENABLED) */

    #if(emFile_UDB_SPI0_TX_SOFTWARE_BUF_ENABLED)
        emFile_UDB_SPI0_txBufferFull  = 0u;
        emFile_UDB_SPI0_txBufferRead  = 0u;
        emFile_UDB_SPI0_txBufferWrite = 0u;
    #endif /* (emFile_UDB_SPI0_TX_SOFTWARE_BUF_ENABLED) */

    /* Clear any data from the RX and TX FIFO */
    emFile_UDB_SPI0_ClearFIFO();

    /* Restore components block enable state */
    if(0u != emFile_UDB_SPI0_backup.enableState)
    {
        emFile_UDB_SPI0_Enable();
    }
}


/* [] END OF FILE */
