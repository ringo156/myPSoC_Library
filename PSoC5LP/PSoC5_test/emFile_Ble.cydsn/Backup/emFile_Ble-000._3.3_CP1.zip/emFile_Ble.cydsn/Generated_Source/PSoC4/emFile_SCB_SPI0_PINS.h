/*******************************************************************************
* File Name: emFile_SCB_SPI0_PINS.h
* Version 3.0
*
* Description:
*  This file provides constants and parameter values for the pin components
*  buried into SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PINS_emFile_SCB_SPI0_H)
#define CY_SCB_PINS_emFile_SCB_SPI0_H

#include "cydevice_trm.h"
#include "cyfitter.h"
#include "cytypes.h"


/***************************************
*   Conditional Compilation Parameters
****************************************/

/* Unconfigured pins */
#define emFile_SCB_SPI0_REMOVE_RX_WAKE_SDA_MOSI_PIN  (1u)
#define emFile_SCB_SPI0_REMOVE_RX_SDA_MOSI_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_TX_SCL_MISO_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_CTS_SCLK_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_RTS_SS0_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_SS1_PIN                 (1u)
#define emFile_SCB_SPI0_REMOVE_SS2_PIN                 (1u)
#define emFile_SCB_SPI0_REMOVE_SS3_PIN                 (1u)

/* Mode defined pins */
#define emFile_SCB_SPI0_REMOVE_I2C_PINS                (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_PINS         (0u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_SCLK_PIN     (0u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_MOSI_PIN     (0u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_MISO_PIN     (0u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS0_PIN      (0u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS1_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS2_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS3_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_SLAVE_PINS          (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_SLAVE_MOSI_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_SPI_SLAVE_MISO_PIN      (1u)
#define emFile_SCB_SPI0_REMOVE_UART_TX_PIN             (1u)
#define emFile_SCB_SPI0_REMOVE_UART_RX_TX_PIN          (1u)
#define emFile_SCB_SPI0_REMOVE_UART_RX_PIN             (1u)
#define emFile_SCB_SPI0_REMOVE_UART_RX_WAKE_PIN        (1u)
#define emFile_SCB_SPI0_REMOVE_UART_RTS_PIN            (1u)
#define emFile_SCB_SPI0_REMOVE_UART_CTS_PIN            (1u)

/* Unconfigured pins */
#define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN (0u == emFile_SCB_SPI0_REMOVE_RX_WAKE_SDA_MOSI_PIN)
#define emFile_SCB_SPI0_RX_SDA_MOSI_PIN     (0u == emFile_SCB_SPI0_REMOVE_RX_SDA_MOSI_PIN)
#define emFile_SCB_SPI0_TX_SCL_MISO_PIN     (0u == emFile_SCB_SPI0_REMOVE_TX_SCL_MISO_PIN)
#define emFile_SCB_SPI0_CTS_SCLK_PIN     (0u == emFile_SCB_SPI0_REMOVE_CTS_SCLK_PIN)
#define emFile_SCB_SPI0_RTS_SS0_PIN     (0u == emFile_SCB_SPI0_REMOVE_RTS_SS0_PIN)
#define emFile_SCB_SPI0_SS1_PIN                (0u == emFile_SCB_SPI0_REMOVE_SS1_PIN)
#define emFile_SCB_SPI0_SS2_PIN                (0u == emFile_SCB_SPI0_REMOVE_SS2_PIN)
#define emFile_SCB_SPI0_SS3_PIN                (0u == emFile_SCB_SPI0_REMOVE_SS3_PIN)

/* Mode defined pins */
#define emFile_SCB_SPI0_I2C_PINS               (0u == emFile_SCB_SPI0_REMOVE_I2C_PINS)
#define emFile_SCB_SPI0_SPI_MASTER_PINS        (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_PINS)
#define emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN    (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_SCLK_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_MOSI_PIN    (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_MOSI_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_MISO_PIN    (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_MISO_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_SS0_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS0_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_SS1_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS1_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_SS2_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS2_PIN)
#define emFile_SCB_SPI0_SPI_MASTER_SS3_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_MASTER_SS3_PIN)
#define emFile_SCB_SPI0_SPI_SLAVE_PINS         (0u == emFile_SCB_SPI0_REMOVE_SPI_SLAVE_PINS)
#define emFile_SCB_SPI0_SPI_SLAVE_MOSI_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_SLAVE_MOSI_PIN)
#define emFile_SCB_SPI0_SPI_SLAVE_MISO_PIN     (0u == emFile_SCB_SPI0_REMOVE_SPI_SLAVE_MISO_PIN)
#define emFile_SCB_SPI0_UART_TX_PIN            (0u == emFile_SCB_SPI0_REMOVE_UART_TX_PIN)
#define emFile_SCB_SPI0_UART_RX_TX_PIN         (0u == emFile_SCB_SPI0_REMOVE_UART_RX_TX_PIN)
#define emFile_SCB_SPI0_UART_RX_PIN            (0u == emFile_SCB_SPI0_REMOVE_UART_RX_PIN)
#define emFile_SCB_SPI0_UART_RX_WAKE_PIN       (0u == emFile_SCB_SPI0_REMOVE_UART_RX_WAKE_PIN)
#define emFile_SCB_SPI0_UART_RTS_PIN           (0u == emFile_SCB_SPI0_REMOVE_UART_RTS_PIN)
#define emFile_SCB_SPI0_UART_CTS_PIN           (0u == emFile_SCB_SPI0_REMOVE_UART_CTS_PIN)


/***************************************
*             Includes
****************************************/

#if (emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN)
    #include "emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi.h"
#endif /* (emFile_SCB_SPI0_RX_SDA_MOSI) */

#if (emFile_SCB_SPI0_RX_SDA_MOSI_PIN)
    #include "emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi.h"
#endif /* (emFile_SCB_SPI0_RX_SDA_MOSI) */

#if (emFile_SCB_SPI0_TX_SCL_MISO_PIN)
    #include "emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso.h"
#endif /* (emFile_SCB_SPI0_TX_SCL_MISO) */

#if (emFile_SCB_SPI0_CTS_SCLK_PIN)
    #include "emFile_SCB_SPI0_uart_cts_spi_sclk.h"
#endif /* (emFile_SCB_SPI0_CTS_SCLK) */

#if (emFile_SCB_SPI0_RTS_SS0_PIN)
    #include "emFile_SCB_SPI0_uart_rts_spi_ss0.h"
#endif /* (emFile_SCB_SPI0_RTS_SS0_PIN) */

#if (emFile_SCB_SPI0_SS1_PIN)
    #include "emFile_SCB_SPI0_spi_ss1.h"
#endif /* (emFile_SCB_SPI0_SS1_PIN) */

#if (emFile_SCB_SPI0_SS2_PIN)
    #include "emFile_SCB_SPI0_spi_ss2.h"
#endif /* (emFile_SCB_SPI0_SS2_PIN) */

#if (emFile_SCB_SPI0_SS3_PIN)
    #include "emFile_SCB_SPI0_spi_ss3.h"
#endif /* (emFile_SCB_SPI0_SS3_PIN) */

#if (emFile_SCB_SPI0_I2C_PINS)
    #include "emFile_SCB_SPI0_scl.h"
    #include "emFile_SCB_SPI0_sda.h"
#endif /* (emFile_SCB_SPI0_I2C_PINS) */

#if (emFile_SCB_SPI0_SPI_MASTER_PINS)
#if (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN)
    #include "emFile_SCB_SPI0_sclk_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_MOSI_PIN)
    #include "emFile_SCB_SPI0_mosi_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_MOSI_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_MISO_PIN)
    #include "emFile_SCB_SPI0_miso_m.h"
#endif /*(emFile_SCB_SPI0_SPI_MASTER_MISO_PIN) */
#endif /* (emFile_SCB_SPI0_SPI_MASTER_PINS) */

#if (emFile_SCB_SPI0_SPI_SLAVE_PINS)
    #include "emFile_SCB_SPI0_sclk_s.h"
    #include "emFile_SCB_SPI0_ss_s.h"

#if (emFile_SCB_SPI0_SPI_SLAVE_MOSI_PIN)
    #include "emFile_SCB_SPI0_mosi_s.h"
#endif /* (emFile_SCB_SPI0_SPI_SLAVE_MOSI_PIN) */

#if (emFile_SCB_SPI0_SPI_SLAVE_MISO_PIN)
    #include "emFile_SCB_SPI0_miso_s.h"
#endif /*(emFile_SCB_SPI0_SPI_SLAVE_MISO_PIN) */
#endif /* (emFile_SCB_SPI0_SPI_SLAVE_PINS) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN)
    #include "emFile_SCB_SPI0_ss0_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN)
    #include "emFile_SCB_SPI0_ss1_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN)
    #include "emFile_SCB_SPI0_ss2_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN)
    #include "emFile_SCB_SPI0_ss3_m.h"
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN) */

#if (emFile_SCB_SPI0_UART_TX_PIN)
    #include "emFile_SCB_SPI0_tx.h"
#endif /* (emFile_SCB_SPI0_UART_TX_PIN) */

#if (emFile_SCB_SPI0_UART_RX_TX_PIN)
    #include "emFile_SCB_SPI0_rx_tx.h"
#endif /* (emFile_SCB_SPI0_UART_RX_TX_PIN) */

#if (emFile_SCB_SPI0_UART_RX_PIN)
    #include "emFile_SCB_SPI0_rx.h"
#endif /* (emFile_SCB_SPI0_UART_RX_PIN) */

#if (emFile_SCB_SPI0_UART_RX_WAKE_PIN)
    #include "emFile_SCB_SPI0_rx_wake.h"
#endif /* (emFile_SCB_SPI0_UART_RX_WAKE_PIN) */

#if (emFile_SCB_SPI0_UART_RTS_PIN)
    #include "emFile_SCB_SPI0_rts.h"
#endif /* (emFile_SCB_SPI0_UART_RTS_PIN) */

#if (emFile_SCB_SPI0_UART_CTS_PIN)
    #include "emFile_SCB_SPI0_cts.h"
#endif /* (emFile_SCB_SPI0_UART_CTS_PIN) */


/***************************************
*              Registers
***************************************/

#if (emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG \
                            (*(reg32 *) emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__HSIOM)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_PTR \
                            ( (reg32 *) emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__HSIOM)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_MASK \
                            (emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_POS \
                            (emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__HSIOM_SHIFT)

    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_INTCFG_REG \
                            (*(reg32 *) emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__INTCFG)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_INTCFG_PTR \
                            ( (reg32 *) emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__0__INTCFG)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_INTCFG_TYPE_POS  (emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi__SHIFT)
    #define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_INTCFG_TYPE_MASK \
                            ((uint32) emFile_SCB_SPI0_INTCFG_TYPE_MASK << \
                                      emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_INTCFG_TYPE_POS)
#endif /* (emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN) */

#if (emFile_SCB_SPI0_RX_SDA_MOSI_PIN)
    #define emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi__0__HSIOM)
    #define emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi__0__HSIOM)
    #define emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_MASK  (emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_POS   (emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_RX_SDA_MOSI_PIN) */

#if (emFile_SCB_SPI0_TX_SCL_MISO_PIN)
    #define emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso__0__HSIOM)
    #define emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso__0__HSIOM)
    #define emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_MASK  (emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_POS   (emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_TX_SCL_MISO_PIN) */

#if (emFile_SCB_SPI0_CTS_SCLK_PIN)
    #define emFile_SCB_SPI0_CTS_SCLK_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_uart_cts_spi_sclk__0__HSIOM)
    #define emFile_SCB_SPI0_CTS_SCLK_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_uart_cts_spi_sclk__0__HSIOM)
    #define emFile_SCB_SPI0_CTS_SCLK_HSIOM_MASK  (emFile_SCB_SPI0_uart_cts_spi_sclk__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_CTS_SCLK_HSIOM_POS   (emFile_SCB_SPI0_uart_cts_spi_sclk__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_CTS_SCLK_PIN) */

#if (emFile_SCB_SPI0_RTS_SS0_PIN)
    #define emFile_SCB_SPI0_RTS_SS0_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_uart_rts_spi_ss0__0__HSIOM)
    #define emFile_SCB_SPI0_RTS_SS0_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_uart_rts_spi_ss0__0__HSIOM)
    #define emFile_SCB_SPI0_RTS_SS0_HSIOM_MASK  (emFile_SCB_SPI0_uart_rts_spi_ss0__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_RTS_SS0_HSIOM_POS   (emFile_SCB_SPI0_uart_rts_spi_ss0__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_RTS_SS0_PIN) */

#if (emFile_SCB_SPI0_SS1_PIN)
    #define emFile_SCB_SPI0_SS1_HSIOM_REG      (*(reg32 *) emFile_SCB_SPI0_spi_ss1__0__HSIOM)
    #define emFile_SCB_SPI0_SS1_HSIOM_PTR      ( (reg32 *) emFile_SCB_SPI0_spi_ss1__0__HSIOM)
    #define emFile_SCB_SPI0_SS1_HSIOM_MASK     (emFile_SCB_SPI0_spi_ss1__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS1_HSIOM_POS      (emFile_SCB_SPI0_spi_ss1__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SS1_PIN) */

#if (emFile_SCB_SPI0_SS2_PIN)
    #define emFile_SCB_SPI0_SS2_HSIOM_REG     (*(reg32 *) emFile_SCB_SPI0_spi_ss2__0__HSIOM)
    #define emFile_SCB_SPI0_SS2_HSIOM_PTR     ( (reg32 *) emFile_SCB_SPI0_spi_ss2__0__HSIOM)
    #define emFile_SCB_SPI0_SS2_HSIOM_MASK    (emFile_SCB_SPI0_spi_ss2__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS2_HSIOM_POS     (emFile_SCB_SPI0_spi_ss2__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SS2_PIN) */

#if (emFile_SCB_SPI0_SS3_PIN)
    #define emFile_SCB_SPI0_SS3_HSIOM_REG     (*(reg32 *) emFile_SCB_SPI0_spi_ss3__0__HSIOM)
    #define emFile_SCB_SPI0_SS3_HSIOM_PTR     ( (reg32 *) emFile_SCB_SPI0_spi_ss3__0__HSIOM)
    #define emFile_SCB_SPI0_SS3_HSIOM_MASK    (emFile_SCB_SPI0_spi_ss3__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS3_HSIOM_POS     (emFile_SCB_SPI0_spi_ss3__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SS3_PIN) */

#if (emFile_SCB_SPI0_I2C_PINS)
    #define emFile_SCB_SPI0_SCL_HSIOM_REG     (*(reg32 *) emFile_SCB_SPI0_scl__0__HSIOM)
    #define emFile_SCB_SPI0_SCL_HSIOM_PTR     ( (reg32 *) emFile_SCB_SPI0_scl__0__HSIOM)
    #define emFile_SCB_SPI0_SCL_HSIOM_MASK    (emFile_SCB_SPI0_scl__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SCL_HSIOM_POS     (emFile_SCB_SPI0_scl__0__HSIOM_SHIFT)

    #define emFile_SCB_SPI0_SDA_HSIOM_REG     (*(reg32 *) emFile_SCB_SPI0_sda__0__HSIOM)
    #define emFile_SCB_SPI0_SDA_HSIOM_PTR     ( (reg32 *) emFile_SCB_SPI0_sda__0__HSIOM)
    #define emFile_SCB_SPI0_SDA_HSIOM_MASK    (emFile_SCB_SPI0_sda__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SDA_HSIOM_POS     (emFile_SCB_SPI0_sda__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_I2C_PINS) */

#if (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN)
    #define emFile_SCB_SPI0_SCLK_M_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_sclk_m__0__HSIOM)
    #define emFile_SCB_SPI0_SCLK_M_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_sclk_m__0__HSIOM)
    #define emFile_SCB_SPI0_SCLK_M_HSIOM_MASK  (emFile_SCB_SPI0_sclk_m__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SCLK_M_HSIOM_POS   (emFile_SCB_SPI0_sclk_m__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN)
    #define emFile_SCB_SPI0_SS0_M_HSIOM_REG    (*(reg32 *) emFile_SCB_SPI0_ss0_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS0_M_HSIOM_PTR    ( (reg32 *) emFile_SCB_SPI0_ss0_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS0_M_HSIOM_MASK   (emFile_SCB_SPI0_ss0_m__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS0_M_HSIOM_POS    (emFile_SCB_SPI0_ss0_m__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN)
    #define emFile_SCB_SPI0_SS1_M_HSIOM_REG    (*(reg32 *) emFile_SCB_SPI0_ss1_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS1_M_HSIOM_PTR    ( (reg32 *) emFile_SCB_SPI0_ss1_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS1_M_HSIOM_MASK   (emFile_SCB_SPI0_ss1_m__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS1_M_HSIOM_POS    (emFile_SCB_SPI0_ss1_m__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN)
    #define emFile_SCB_SPI0_SS2_M_HSIOM_REG    (*(reg32 *) emFile_SCB_SPI0_ss2_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS2_M_HSIOM_PTR    ( (reg32 *) emFile_SCB_SPI0_ss2_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS2_M_HSIOM_MASK   (emFile_SCB_SPI0_ss2_m__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS2_M_HSIOM_POS    (emFile_SCB_SPI0_ss2_m__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN)
    #define emFile_SCB_SPI0_SS3_M_HSIOM_REG    (*(reg32 *) emFile_SCB_SPI0_ss3_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS3_M_HSIOM_PTR    ( (reg32 *) emFile_SCB_SPI0_ss3_m__0__HSIOM)
    #define emFile_SCB_SPI0_SS3_M_HSIOM_MASK   (emFile_SCB_SPI0_ss3_m__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_SS3_M_HSIOM_POS    (emFile_SCB_SPI0_ss3_m__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN) */

#if (emFile_SCB_SPI0_UART_TX_PIN)
    #define emFile_SCB_SPI0_TX_HSIOM_REG   (*(reg32 *) emFile_SCB_SPI0_tx__0__HSIOM)
    #define emFile_SCB_SPI0_TX_HSIOM_PTR   ( (reg32 *) emFile_SCB_SPI0_tx_0__HSIOM)
    #define emFile_SCB_SPI0_TX_HSIOM_MASK  (emFile_SCB_SPI0_tx__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_TX_HSIOM_POS   (emFile_SCB_SPI0_tx__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_UART_TX_PIN) */

#if (emFile_SCB_SPI0_UART_RTS_PIN)
    #define emFile_SCB_SPI0_RTS_HSIOM_REG  (*(reg32 *) emFile_SCB_SPI0_rts__0__HSIOM)
    #define emFile_SCB_SPI0_RTS_HSIOM_PTR  ( (reg32 *) emFile_SCB_SPI0_rts__0__HSIOM)
    #define emFile_SCB_SPI0_RTS_HSIOM_MASK (emFile_SCB_SPI0_rts__0__HSIOM_MASK)
    #define emFile_SCB_SPI0_RTS_HSIOM_POS  (emFile_SCB_SPI0_rts__0__HSIOM_SHIFT)
#endif /* (emFile_SCB_SPI0_UART_RTS_PIN) */


/***************************************
*        Registers Constants
***************************************/

/* Pins constants */
#define emFile_SCB_SPI0_HSIOM_DEF_SEL      (0x00u)
#define emFile_SCB_SPI0_HSIOM_GPIO_SEL     (0x00u)
#define emFile_SCB_SPI0_HSIOM_UART_SEL     (0x09u)
#define emFile_SCB_SPI0_HSIOM_I2C_SEL      (0x0Eu)
#define emFile_SCB_SPI0_HSIOM_SPI_SEL      (0x0Fu)

#define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN_INDEX   (0u)
#define emFile_SCB_SPI0_RX_SDA_MOSI_PIN_INDEX       (0u)
#define emFile_SCB_SPI0_TX_SCL_MISO_PIN_INDEX       (1u)
#define emFile_SCB_SPI0_CTS_SCLK_PIN_INDEX       (2u)
#define emFile_SCB_SPI0_RTS_SS0_PIN_INDEX       (3u)
#define emFile_SCB_SPI0_SS1_PIN_INDEX                  (4u)
#define emFile_SCB_SPI0_SS2_PIN_INDEX                  (5u)
#define emFile_SCB_SPI0_SS3_PIN_INDEX                  (6u)

#define emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN_MASK ((uint32) 0x01u << emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN_INDEX)
#define emFile_SCB_SPI0_RX_SDA_MOSI_PIN_MASK     ((uint32) 0x01u << emFile_SCB_SPI0_RX_SDA_MOSI_PIN_INDEX)
#define emFile_SCB_SPI0_TX_SCL_MISO_PIN_MASK     ((uint32) 0x01u << emFile_SCB_SPI0_TX_SCL_MISO_PIN_INDEX)
#define emFile_SCB_SPI0_CTS_SCLK_PIN_MASK     ((uint32) 0x01u << emFile_SCB_SPI0_CTS_SCLK_PIN_INDEX)
#define emFile_SCB_SPI0_RTS_SS0_PIN_MASK     ((uint32) 0x01u << emFile_SCB_SPI0_RTS_SS0_PIN_INDEX)
#define emFile_SCB_SPI0_SS1_PIN_MASK                ((uint32) 0x01u << emFile_SCB_SPI0_SS1_PIN_INDEX)
#define emFile_SCB_SPI0_SS2_PIN_MASK                ((uint32) 0x01u << emFile_SCB_SPI0_SS2_PIN_INDEX)
#define emFile_SCB_SPI0_SS3_PIN_MASK                ((uint32) 0x01u << emFile_SCB_SPI0_SS3_PIN_INDEX)

/* Pin interrupt constants */
#define emFile_SCB_SPI0_INTCFG_TYPE_MASK           (0x03u)
#define emFile_SCB_SPI0_INTCFG_TYPE_FALLING_EDGE   (0x02u)

/* Pin Drive Mode constants */
#define emFile_SCB_SPI0_PIN_DM_ALG_HIZ  (0u)
#define emFile_SCB_SPI0_PIN_DM_DIG_HIZ  (1u)
#define emFile_SCB_SPI0_PIN_DM_OD_LO    (4u)
#define emFile_SCB_SPI0_PIN_DM_STRONG   (6u)


/***************************************
*          Macro Definitions
***************************************/

/* Return drive mode of the pin */
#define emFile_SCB_SPI0_DM_MASK    (0x7u)
#define emFile_SCB_SPI0_DM_SIZE    (3)
#define emFile_SCB_SPI0_GET_P4_PIN_DM(reg, pos) \
    ( ((reg) & (uint32) ((uint32) emFile_SCB_SPI0_DM_MASK << (emFile_SCB_SPI0_DM_SIZE * (pos)))) >> \
                                                              (emFile_SCB_SPI0_DM_SIZE * (pos)) )

#if (emFile_SCB_SPI0_TX_SCL_MISO_PIN)
    #define emFile_SCB_SPI0_CHECK_TX_SCL_MISO_PIN_USED \
                (emFile_SCB_SPI0_PIN_DM_ALG_HIZ != \
                    emFile_SCB_SPI0_GET_P4_PIN_DM(emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso_PC, \
                                                   emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso_SHIFT))
#endif /* (emFile_SCB_SPI0_TX_SCL_MISO_PIN) */

#if (emFile_SCB_SPI0_RTS_SS0_PIN)
    #define emFile_SCB_SPI0_CHECK_RTS_SS0_PIN_USED \
                (emFile_SCB_SPI0_PIN_DM_ALG_HIZ != \
                    emFile_SCB_SPI0_GET_P4_PIN_DM(emFile_SCB_SPI0_uart_rts_spi_ss0_PC, \
                                                   emFile_SCB_SPI0_uart_rts_spi_ss0_SHIFT))
#endif /* (emFile_SCB_SPI0_RTS_SS0_PIN) */

/* Set bits-mask in register */
#define emFile_SCB_SPI0_SET_REGISTER_BITS(reg, mask, pos, mode) \
                    do                                           \
                    {                                            \
                        (reg) = (((reg) & ((uint32) ~(uint32) (mask))) | ((uint32) ((uint32) (mode) << (pos)))); \
                    }while(0)

/* Set bit in the register */
#define emFile_SCB_SPI0_SET_REGISTER_BIT(reg, mask, val) \
                    ((val) ? ((reg) |= (mask)) : ((reg) &= ((uint32) ~((uint32) (mask)))))

#define emFile_SCB_SPI0_SET_HSIOM_SEL(reg, mask, pos, sel) emFile_SCB_SPI0_SET_REGISTER_BITS(reg, mask, pos, sel)
#define emFile_SCB_SPI0_SET_INCFG_TYPE(reg, mask, pos, intType) \
                                                        emFile_SCB_SPI0_SET_REGISTER_BITS(reg, mask, pos, intType)
#define emFile_SCB_SPI0_SET_INP_DIS(reg, mask, val) emFile_SCB_SPI0_SET_REGISTER_BIT(reg, mask, val)

/* emFile_SCB_SPI0_SET_I2C_SCL_DR(val) - Sets I2C SCL DR register.
*  emFile_SCB_SPI0_SET_I2C_SCL_HSIOM_SEL(sel) - Sets I2C SCL HSIOM settings.
*/
/* SCB I2C: scl signal */
#if (emFile_SCB_SPI0_CY_SCBIP_V0)
#if (emFile_SCB_SPI0_I2C_PINS)
    #define emFile_SCB_SPI0_SET_I2C_SCL_DR(val) emFile_SCB_SPI0_scl_Write(val)

    #define emFile_SCB_SPI0_SET_I2C_SCL_HSIOM_SEL(sel) \
                          emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SCL_HSIOM_REG,  \
                                                         emFile_SCB_SPI0_SCL_HSIOM_MASK, \
                                                         emFile_SCB_SPI0_SCL_HSIOM_POS,  \
                                                         (sel))
    #define emFile_SCB_SPI0_WAIT_SCL_SET_HIGH  (0u == emFile_SCB_SPI0_scl_Read())

/* Unconfigured SCB: scl signal */
#elif (emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN)
    #define emFile_SCB_SPI0_SET_I2C_SCL_DR(val) \
                            emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi_Write(val)

    #define emFile_SCB_SPI0_SET_I2C_SCL_HSIOM_SEL(sel) \
                    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG,  \
                                                   emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_MASK, \
                                                   emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_POS,  \
                                                   (sel))

    #define emFile_SCB_SPI0_WAIT_SCL_SET_HIGH  (0u == emFile_SCB_SPI0_uart_rx_wake_i2c_sda_spi_mosi_Read())

#elif (emFile_SCB_SPI0_RX_SDA_MOSI_PIN)
    #define emFile_SCB_SPI0_SET_I2C_SCL_DR(val) \
                            emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi_Write(val)


    #define emFile_SCB_SPI0_SET_I2C_SCL_HSIOM_SEL(sel) \
                            emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_REG,  \
                                                           emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_MASK, \
                                                           emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_POS,  \
                                                           (sel))

    #define emFile_SCB_SPI0_WAIT_SCL_SET_HIGH  (0u == emFile_SCB_SPI0_uart_rx_i2c_sda_spi_mosi_Read())

#else
    #define emFile_SCB_SPI0_SET_I2C_SCL_DR(val) \
                                                    do{ /* Does nothing */ }while(0)
    #define emFile_SCB_SPI0_SET_I2C_SCL_HSIOM_SEL(sel) \
                                                    do{ /* Does nothing */ }while(0)

    #define emFile_SCB_SPI0_WAIT_SCL_SET_HIGH  (0u)
#endif /* (emFile_SCB_SPI0_I2C_PINS) */

/* SCB I2C: sda signal */
#if (emFile_SCB_SPI0_I2C_PINS)
    #define emFile_SCB_SPI0_WAIT_SDA_SET_HIGH  (0u == emFile_SCB_SPI0_sda_Read())
/* Unconfigured SCB: sda signal */
#elif (emFile_SCB_SPI0_TX_SCL_MISO_PIN)
    #define emFile_SCB_SPI0_WAIT_SDA_SET_HIGH  (0u == emFile_SCB_SPI0_uart_tx_i2c_scl_spi_miso_Read())
#else
    #define emFile_SCB_SPI0_WAIT_SDA_SET_HIGH  (0u)
#endif /* (emFile_SCB_SPI0_MOSI_SCL_RX_PIN) */
#endif /* (emFile_SCB_SPI0_CY_SCBIP_V0) */


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Unconfigured pins */
#define emFile_SCB_SPI0_REMOVE_MOSI_SCL_RX_WAKE_PIN    emFile_SCB_SPI0_REMOVE_RX_WAKE_SDA_MOSI_PIN
#define emFile_SCB_SPI0_REMOVE_MOSI_SCL_RX_PIN         emFile_SCB_SPI0_REMOVE_RX_SDA_MOSI_PIN
#define emFile_SCB_SPI0_REMOVE_MISO_SDA_TX_PIN         emFile_SCB_SPI0_REMOVE_TX_SCL_MISO_PIN
#ifndef emFile_SCB_SPI0_REMOVE_SCLK_PIN
#define emFile_SCB_SPI0_REMOVE_SCLK_PIN                emFile_SCB_SPI0_REMOVE_CTS_SCLK_PIN
#endif /* emFile_SCB_SPI0_REMOVE_SCLK_PIN */
#ifndef emFile_SCB_SPI0_REMOVE_SS0_PIN
#define emFile_SCB_SPI0_REMOVE_SS0_PIN                 emFile_SCB_SPI0_REMOVE_RTS_SS0_PIN
#endif /* emFile_SCB_SPI0_REMOVE_SS0_PIN */

/* Unconfigured pins */
#define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_PIN   emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN
#define emFile_SCB_SPI0_MOSI_SCL_RX_PIN        emFile_SCB_SPI0_RX_SDA_MOSI_PIN
#define emFile_SCB_SPI0_MISO_SDA_TX_PIN        emFile_SCB_SPI0_TX_SCL_MISO_PIN
#ifndef emFile_SCB_SPI0_SCLK_PIN
#define emFile_SCB_SPI0_SCLK_PIN               emFile_SCB_SPI0_CTS_SCLK_PIN
#endif /* emFile_SCB_SPI0_SCLK_PIN */
#ifndef emFile_SCB_SPI0_SS0_PIN
#define emFile_SCB_SPI0_SS0_PIN                emFile_SCB_SPI0_RTS_SS0_PIN
#endif /* emFile_SCB_SPI0_SS0_PIN */

#if (emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_PIN)
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_HSIOM_REG     emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_HSIOM_PTR     emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_HSIOM_MASK    emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_HSIOM_POS     emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG

    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_INTCFG_REG    emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_INTCFG_PTR    emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG

    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_INTCFG_TYPE_POS   emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_INTCFG_TYPE_MASK  emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_HSIOM_REG
#endif /* (emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN) */

#if (emFile_SCB_SPI0_MOSI_SCL_RX_PIN)
    #define emFile_SCB_SPI0_MOSI_SCL_RX_HSIOM_REG      emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_REG
    #define emFile_SCB_SPI0_MOSI_SCL_RX_HSIOM_PTR      emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_PTR
    #define emFile_SCB_SPI0_MOSI_SCL_RX_HSIOM_MASK     emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_MASK
    #define emFile_SCB_SPI0_MOSI_SCL_RX_HSIOM_POS      emFile_SCB_SPI0_RX_SDA_MOSI_HSIOM_POS
#endif /* (emFile_SCB_SPI0_MOSI_SCL_RX_PIN) */

#if (emFile_SCB_SPI0_MISO_SDA_TX_PIN)
    #define emFile_SCB_SPI0_MISO_SDA_TX_HSIOM_REG      emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_REG
    #define emFile_SCB_SPI0_MISO_SDA_TX_HSIOM_PTR      emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_REG
    #define emFile_SCB_SPI0_MISO_SDA_TX_HSIOM_MASK     emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_REG
    #define emFile_SCB_SPI0_MISO_SDA_TX_HSIOM_POS      emFile_SCB_SPI0_TX_SCL_MISO_HSIOM_REG
#endif /* (emFile_SCB_SPI0_MISO_SDA_TX_PIN_PIN) */

#if (emFile_SCB_SPI0_SCLK_PIN)
    #ifndef emFile_SCB_SPI0_SCLK_HSIOM_REG
    #define emFile_SCB_SPI0_SCLK_HSIOM_REG     emFile_SCB_SPI0_CTS_SCLK_HSIOM_REG
    #define emFile_SCB_SPI0_SCLK_HSIOM_PTR     emFile_SCB_SPI0_CTS_SCLK_HSIOM_PTR
    #define emFile_SCB_SPI0_SCLK_HSIOM_MASK    emFile_SCB_SPI0_CTS_SCLK_HSIOM_MASK
    #define emFile_SCB_SPI0_SCLK_HSIOM_POS     emFile_SCB_SPI0_CTS_SCLK_HSIOM_POS
    #endif /* emFile_SCB_SPI0_SCLK_HSIOM_REG */
#endif /* (emFile_SCB_SPI0_SCLK_PIN) */

#if (emFile_SCB_SPI0_SS0_PIN)
    #ifndef emFile_SCB_SPI0_SS0_HSIOM_REG
    #define emFile_SCB_SPI0_SS0_HSIOM_REG      emFile_SCB_SPI0_RTS_SS0_HSIOM_REG
    #define emFile_SCB_SPI0_SS0_HSIOM_PTR      emFile_SCB_SPI0_RTS_SS0_HSIOM_PTR
    #define emFile_SCB_SPI0_SS0_HSIOM_MASK     emFile_SCB_SPI0_RTS_SS0_HSIOM_MASK
    #define emFile_SCB_SPI0_SS0_HSIOM_POS      emFile_SCB_SPI0_RTS_SS0_HSIOM_POS
    #endif /* emFile_SCB_SPI0_SS0_HSIOM_REG */
#endif /* (emFile_SCB_SPI0_SS0_PIN) */

#define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_PIN_INDEX emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN_INDEX
#define emFile_SCB_SPI0_MOSI_SCL_RX_PIN_INDEX      emFile_SCB_SPI0_RX_SDA_MOSI_PIN_INDEX
#define emFile_SCB_SPI0_MISO_SDA_TX_PIN_INDEX      emFile_SCB_SPI0_TX_SCL_MISO_PIN_INDEX
#ifndef emFile_SCB_SPI0_SCLK_PIN_INDEX
#define emFile_SCB_SPI0_SCLK_PIN_INDEX             emFile_SCB_SPI0_CTS_SCLK_PIN_INDEX
#endif /* emFile_SCB_SPI0_SCLK_PIN_INDEX */
#ifndef emFile_SCB_SPI0_SS0_PIN_INDEX
#define emFile_SCB_SPI0_SS0_PIN_INDEX              emFile_SCB_SPI0_RTS_SS0_PIN_INDEX
#endif /* emFile_SCB_SPI0_SS0_PIN_INDEX */

#define emFile_SCB_SPI0_MOSI_SCL_RX_WAKE_PIN_MASK emFile_SCB_SPI0_RX_WAKE_SDA_MOSI_PIN_MASK
#define emFile_SCB_SPI0_MOSI_SCL_RX_PIN_MASK      emFile_SCB_SPI0_RX_SDA_MOSI_PIN_MASK
#define emFile_SCB_SPI0_MISO_SDA_TX_PIN_MASK      emFile_SCB_SPI0_TX_SCL_MISO_PIN_MASK
#ifndef emFile_SCB_SPI0_SCLK_PIN_MASK
#define emFile_SCB_SPI0_SCLK_PIN_MASK             emFile_SCB_SPI0_CTS_SCLK_PIN_MASK
#endif /* emFile_SCB_SPI0_SCLK_PIN_MASK */
#ifndef emFile_SCB_SPI0_SS0_PIN_MASK
#define emFile_SCB_SPI0_SS0_PIN_MASK              emFile_SCB_SPI0_RTS_SS0_PIN_MASK
#endif /* emFile_SCB_SPI0_SS0_PIN_MASK */

#endif /* (CY_SCB_PINS_emFile_SCB_SPI0_H) */


/* [] END OF FILE */
