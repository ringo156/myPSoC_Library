/*******************************************************************************
* File Name: emFile_SCB_SPI0_SPI.c
* Version 3.0
*
* Description:
*  This file provides the source code to the API for the SCB Component in
*  SPI mode.
*
* Note:
*
*******************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "emFile_SCB_SPI0_PVT.h"
#include "emFile_SCB_SPI0_SPI_UART_PVT.h"

#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)

    /***************************************
    *  Configuration Structure Initialization
    ***************************************/

    const emFile_SCB_SPI0_SPI_INIT_STRUCT emFile_SCB_SPI0_configSpi =
    {
        emFile_SCB_SPI0_SPI_MODE,
        emFile_SCB_SPI0_SPI_SUB_MODE,
        emFile_SCB_SPI0_SPI_CLOCK_MODE,
        emFile_SCB_SPI0_SPI_OVS_FACTOR,
        emFile_SCB_SPI0_SPI_MEDIAN_FILTER_ENABLE,
        emFile_SCB_SPI0_SPI_LATE_MISO_SAMPLE_ENABLE,
        emFile_SCB_SPI0_SPI_WAKE_ENABLE,
        emFile_SCB_SPI0_SPI_RX_DATA_BITS_NUM,
        emFile_SCB_SPI0_SPI_TX_DATA_BITS_NUM,
        emFile_SCB_SPI0_SPI_BITS_ORDER,
        emFile_SCB_SPI0_SPI_TRANSFER_SEPARATION,
        0u,
        NULL,
        0u,
        NULL,
        (uint32) emFile_SCB_SPI0_SCB_IRQ_INTERNAL,
        emFile_SCB_SPI0_SPI_INTR_RX_MASK,
        emFile_SCB_SPI0_SPI_RX_TRIGGER_LEVEL,
        emFile_SCB_SPI0_SPI_INTR_TX_MASK,
        emFile_SCB_SPI0_SPI_TX_TRIGGER_LEVEL,
        (uint8) emFile_SCB_SPI0_SPI_BYTE_MODE_ENABLE,
        (uint8) emFile_SCB_SPI0_SPI_FREE_RUN_SCLK_ENABLE,
        (uint8) emFile_SCB_SPI0_SPI_SS_POLARITY
    };


    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SpiInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for the SPI operation.
    *
    * Parameters:
    *  config:  Pointer to a structure that contains the following ordered list of
    *           fields. These fields match the selections available in the
    *           customizer.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiInit(const emFile_SCB_SPI0_SPI_INIT_STRUCT *config)
    {
        if(NULL == config)
        {
            CYASSERT(0u != 0u); /* Halt execution due to bad function parameter */
        }
        else
        {
            /* Configure pins */
            emFile_SCB_SPI0_SetPins(emFile_SCB_SPI0_SCB_MODE_SPI, config->mode, emFile_SCB_SPI0_DUMMY_PARAM);

            /* Store internal configuration */
            emFile_SCB_SPI0_scbMode       = (uint8) emFile_SCB_SPI0_SCB_MODE_SPI;
            emFile_SCB_SPI0_scbEnableWake = (uint8) config->enableWake;
            emFile_SCB_SPI0_scbEnableIntr = (uint8) config->enableInterrupt;

            /* Set RX direction internal variables */
            emFile_SCB_SPI0_rxBuffer      =         config->rxBuffer;
            emFile_SCB_SPI0_rxDataBits    = (uint8) config->rxDataBits;
            emFile_SCB_SPI0_rxBufferSize  = (uint8) config->rxBufferSize;

            /* Set TX direction internal variables */
            emFile_SCB_SPI0_txBuffer      =         config->txBuffer;
            emFile_SCB_SPI0_txDataBits    = (uint8) config->txDataBits;
            emFile_SCB_SPI0_txBufferSize  = (uint8) config->txBufferSize;

            /* Configure SPI interface */
            emFile_SCB_SPI0_CTRL_REG     = emFile_SCB_SPI0_GET_CTRL_OVS(config->oversample)           |
                                            emFile_SCB_SPI0_GET_CTRL_BYTE_MODE(config->enableByteMode) |
                                            emFile_SCB_SPI0_GET_CTRL_EC_AM_MODE(config->enableWake)    |
                                            emFile_SCB_SPI0_CTRL_SPI;

            emFile_SCB_SPI0_SPI_CTRL_REG = emFile_SCB_SPI0_GET_SPI_CTRL_CONTINUOUS    (config->transferSeperation)  |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_SELECT_PRECEDE(config->submode &
                                                                          emFile_SCB_SPI0_SPI_MODE_TI_PRECEDES_MASK) |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_SCLK_MODE     (config->sclkMode)            |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_LATE_MISO_SAMPLE(config->enableLateSampling)|
                                            emFile_SCB_SPI0_GET_SPI_CTRL_SCLK_CONTINUOUS(config->enableFreeRunSclk)  |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_SSEL_POLARITY (config->polaritySs)          |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_SUB_MODE      (config->submode)             |
                                            emFile_SCB_SPI0_GET_SPI_CTRL_MASTER_MODE   (config->mode);

            /* Configure RX direction */
            emFile_SCB_SPI0_RX_CTRL_REG     =  emFile_SCB_SPI0_GET_RX_CTRL_DATA_WIDTH(config->rxDataBits)         |
                                                emFile_SCB_SPI0_GET_RX_CTRL_BIT_ORDER (config->bitOrder)           |
                                                emFile_SCB_SPI0_GET_RX_CTRL_MEDIAN    (config->enableMedianFilter) |
                                                emFile_SCB_SPI0_SPI_RX_CTRL;

            emFile_SCB_SPI0_RX_FIFO_CTRL_REG = emFile_SCB_SPI0_GET_RX_FIFO_CTRL_TRIGGER_LEVEL(config->rxTriggerLevel);

            /* Configure TX direction */
            emFile_SCB_SPI0_TX_CTRL_REG      = emFile_SCB_SPI0_GET_TX_CTRL_DATA_WIDTH(config->txDataBits) |
                                                emFile_SCB_SPI0_GET_TX_CTRL_BIT_ORDER (config->bitOrder)   |
                                                emFile_SCB_SPI0_SPI_TX_CTRL;

            emFile_SCB_SPI0_TX_FIFO_CTRL_REG = emFile_SCB_SPI0_GET_TX_FIFO_CTRL_TRIGGER_LEVEL(config->txTriggerLevel);

            /* Configure interrupt with SPI handler but do not enable it */
            CyIntDisable    (emFile_SCB_SPI0_ISR_NUMBER);
            CyIntSetPriority(emFile_SCB_SPI0_ISR_NUMBER, emFile_SCB_SPI0_ISR_PRIORITY);
            (void) CyIntSetVector(emFile_SCB_SPI0_ISR_NUMBER, &emFile_SCB_SPI0_SPI_UART_ISR);

            /* Configure interrupt sources */
            emFile_SCB_SPI0_INTR_I2C_EC_MASK_REG = emFile_SCB_SPI0_NO_INTR_SOURCES;
            emFile_SCB_SPI0_INTR_SPI_EC_MASK_REG = emFile_SCB_SPI0_NO_INTR_SOURCES;
            emFile_SCB_SPI0_INTR_SLAVE_MASK_REG  = emFile_SCB_SPI0_GET_SPI_INTR_SLAVE_MASK(config->rxInterruptMask);
            emFile_SCB_SPI0_INTR_MASTER_MASK_REG = emFile_SCB_SPI0_GET_SPI_INTR_MASTER_MASK(config->txInterruptMask);
            emFile_SCB_SPI0_INTR_RX_MASK_REG     = emFile_SCB_SPI0_GET_SPI_INTR_RX_MASK(config->rxInterruptMask);
            emFile_SCB_SPI0_INTR_TX_MASK_REG     = emFile_SCB_SPI0_GET_SPI_INTR_TX_MASK(config->txInterruptMask);

            /* Set active SS0 */
            emFile_SCB_SPI0_SpiSetActiveSlaveSelect(emFile_SCB_SPI0_SPI_SLAVE_SELECT0);

            /* Clear RX buffer indexes */
            emFile_SCB_SPI0_rxBufferHead     = 0u;
            emFile_SCB_SPI0_rxBufferTail     = 0u;
            emFile_SCB_SPI0_rxBufferOverflow = 0u;

            /* Clear TX buffer indexes */
            emFile_SCB_SPI0_txBufferHead = 0u;
            emFile_SCB_SPI0_txBufferTail = 0u;
        }
    }

#else

    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SpiInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for the SPI operation.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiInit(void)
    {
        /* Configure SPI interface */
        emFile_SCB_SPI0_CTRL_REG     = emFile_SCB_SPI0_SPI_DEFAULT_CTRL;
        emFile_SCB_SPI0_SPI_CTRL_REG = emFile_SCB_SPI0_SPI_DEFAULT_SPI_CTRL;

        /* Configure TX and RX direction */
        emFile_SCB_SPI0_RX_CTRL_REG      = emFile_SCB_SPI0_SPI_DEFAULT_RX_CTRL;
        emFile_SCB_SPI0_RX_FIFO_CTRL_REG = emFile_SCB_SPI0_SPI_DEFAULT_RX_FIFO_CTRL;

        /* Configure TX and RX direction */
        emFile_SCB_SPI0_TX_CTRL_REG      = emFile_SCB_SPI0_SPI_DEFAULT_TX_CTRL;
        emFile_SCB_SPI0_TX_FIFO_CTRL_REG = emFile_SCB_SPI0_SPI_DEFAULT_TX_FIFO_CTRL;

        /* Configure interrupt with SPI handler but do not enable it */
    #if(emFile_SCB_SPI0_SCB_IRQ_INTERNAL)
            CyIntDisable    (emFile_SCB_SPI0_ISR_NUMBER);
            CyIntSetPriority(emFile_SCB_SPI0_ISR_NUMBER, emFile_SCB_SPI0_ISR_PRIORITY);
            (void) CyIntSetVector(emFile_SCB_SPI0_ISR_NUMBER, &emFile_SCB_SPI0_SPI_UART_ISR);
    #endif /* (emFile_SCB_SPI0_SCB_IRQ_INTERNAL) */

        /* Configure interrupt sources */
        emFile_SCB_SPI0_INTR_I2C_EC_MASK_REG = emFile_SCB_SPI0_SPI_DEFAULT_INTR_I2C_EC_MASK;
        emFile_SCB_SPI0_INTR_SPI_EC_MASK_REG = emFile_SCB_SPI0_SPI_DEFAULT_INTR_SPI_EC_MASK;
        emFile_SCB_SPI0_INTR_SLAVE_MASK_REG  = emFile_SCB_SPI0_SPI_DEFAULT_INTR_SLAVE_MASK;
        emFile_SCB_SPI0_INTR_MASTER_MASK_REG = emFile_SCB_SPI0_SPI_DEFAULT_INTR_MASTER_MASK;
        emFile_SCB_SPI0_INTR_RX_MASK_REG     = emFile_SCB_SPI0_SPI_DEFAULT_INTR_RX_MASK;
        emFile_SCB_SPI0_INTR_TX_MASK_REG     = emFile_SCB_SPI0_SPI_DEFAULT_INTR_TX_MASK;

        /* Set active SS0 for master */
    #if (emFile_SCB_SPI0_SPI_MASTER_CONST)
        emFile_SCB_SPI0_SpiSetActiveSlaveSelect(emFile_SCB_SPI0_SPI_SLAVE_SELECT0);
    #endif /* (emFile_SCB_SPI0_SPI_MASTER_CONST) */

    #if(emFile_SCB_SPI0_INTERNAL_RX_SW_BUFFER_CONST)
        emFile_SCB_SPI0_rxBufferHead     = 0u;
        emFile_SCB_SPI0_rxBufferTail     = 0u;
        emFile_SCB_SPI0_rxBufferOverflow = 0u;
    #endif /* (emFile_SCB_SPI0_INTERNAL_RX_SW_BUFFER_CONST) */

    #if(emFile_SCB_SPI0_INTERNAL_TX_SW_BUFFER_CONST)
        emFile_SCB_SPI0_txBufferHead = 0u;
        emFile_SCB_SPI0_txBufferTail = 0u;
    #endif /* (emFile_SCB_SPI0_INTERNAL_TX_SW_BUFFER_CONST) */
    }
#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */


/*******************************************************************************
* Function Name: emFile_SCB_SPI0_SpiPostEnable
********************************************************************************
*
* Summary:
*  Restores HSIOM settings for the SPI master output pins (SCLK and/or SS0-SS3) 
*  to be controlled by the SCB SPI.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void emFile_SCB_SPI0_SpiPostEnable(void)
{
#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)

    if (emFile_SCB_SPI0_CHECK_SPI_MASTER)
    {
    #if (emFile_SCB_SPI0_CTS_SCLK_PIN)
        /* Set SCB SPI to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_CTS_SCLK_HSIOM_REG, emFile_SCB_SPI0_CTS_SCLK_HSIOM_MASK,
                                       emFile_SCB_SPI0_CTS_SCLK_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
    #endif /* (emFile_SCB_SPI0_CTS_SCLK_PIN) */

    #if (emFile_SCB_SPI0_RTS_SS0_PIN)
        /* Set SCB SPI to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_RTS_SS0_HSIOM_REG, emFile_SCB_SPI0_RTS_SS0_HSIOM_MASK,
                                       emFile_SCB_SPI0_RTS_SS0_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
    #endif /* (emFile_SCB_SPI0_RTS_SS0_PIN) */

    #if (emFile_SCB_SPI0_SS1_PIN)
        /* Set SCB SPI to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS1_HSIOM_REG, emFile_SCB_SPI0_SS1_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS1_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
    #endif /* (emFile_SCB_SPI0_SS1_PIN) */

    #if (emFile_SCB_SPI0_SS2_PIN)
        /* Set SCB SPI to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS2_HSIOM_REG, emFile_SCB_SPI0_SS2_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS2_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
    #endif /* (emFile_SCB_SPI0_SS2_PIN) */

    #if (emFile_SCB_SPI0_SS3_PIN)
        /* Set SCB SPI to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS3_HSIOM_REG, emFile_SCB_SPI0_SS3_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS3_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
    #endif /* (emFile_SCB_SPI0_SS3_PIN) */
    }

#else

#if (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN)
    /* Set SCB SPI to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SCLK_M_HSIOM_REG, emFile_SCB_SPI0_SCLK_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SCLK_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
#endif /* (emFile_SCB_SPI0_MISO_SDA_TX_PIN_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN)
    /* Set SCB SPI to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS0_M_HSIOM_REG, emFile_SCB_SPI0_SS0_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS0_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN)
    /* Set SCB SPI to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS1_M_HSIOM_REG, emFile_SCB_SPI0_SS1_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS1_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN)
    /* Set SCB SPI to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS2_M_HSIOM_REG, emFile_SCB_SPI0_SS2_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS2_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN)
    /* Set SCB SPI to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS3_M_HSIOM_REG, emFile_SCB_SPI0_SS3_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS3_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_SPI_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN) */

#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: emFile_SCB_SPI0_SpiStop
********************************************************************************
*
* Summary:
*  Changes the HSIOM settings for the SPI master output pins (SCLK and/or SS0-SS3) to
*  keep them inactive after the block is disabled. The output pins are
*  controlled by the GPIO data register.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void emFile_SCB_SPI0_SpiStop(void)
{
#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)

    if (emFile_SCB_SPI0_CHECK_SPI_MASTER)
    {
    #if (emFile_SCB_SPI0_SCLK_PIN)
        /* Set output pin state after block is disabled */
        emFile_SCB_SPI0_uart_cts_spi_sclk_Write(emFile_SCB_SPI0_GET_SPI_SCLK_INACTIVE);

        /* Set GPIO to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SCLK_HSIOM_REG, emFile_SCB_SPI0_SCLK_HSIOM_MASK,
                                       emFile_SCB_SPI0_SCLK_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
    #endif /* (emFile_SCB_SPI0_MISO_SDA_TX_PIN_PIN) */

    #if (emFile_SCB_SPI0_SS0_PIN)
        /* Set output pin state after block is disabled */
        emFile_SCB_SPI0_uart_rts_spi_ss0_Write(emFile_SCB_SPI0_GET_SPI_SS0_INACTIVE);

        /* Set GPIO to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS0_HSIOM_REG, emFile_SCB_SPI0_SS0_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS0_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
    #endif /* (emFile_SCB_SPI0_SS0_PIN) */

    #if (emFile_SCB_SPI0_SS1_PIN)
        /* Set output pin state after block is disabled */
        emFile_SCB_SPI0_spi_ss1_Write(emFile_SCB_SPI0_GET_SPI_SS1_INACTIVE);

        /* Set GPIO to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS1_HSIOM_REG, emFile_SCB_SPI0_SS1_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS1_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
    #endif /* (emFile_SCB_SPI0_SS1_PIN) */

    #if (emFile_SCB_SPI0_SS2_PIN)
        /* Set output pin state after block is disabled */
        emFile_SCB_SPI0_spi_ss2_Write(emFile_SCB_SPI0_GET_SPI_SS2_INACTIVE);

        /* Set GPIO to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS2_HSIOM_REG, emFile_SCB_SPI0_SS2_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS2_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
    #endif /* (emFile_SCB_SPI0_SS2_PIN) */

    #if (emFile_SCB_SPI0_SS3_PIN)
        /* Set output pin state after block is disabled */
        emFile_SCB_SPI0_spi_ss3_Write(emFile_SCB_SPI0_GET_SPI_SS3_INACTIVE);

        /* Set GPIO to drive output pin */
        emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS3_HSIOM_REG, emFile_SCB_SPI0_SS3_HSIOM_MASK,
                                       emFile_SCB_SPI0_SS3_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
    #endif /* (emFile_SCB_SPI0_SS3_PIN) */
    }

#else

#if (emFile_SCB_SPI0_SPI_MASTER_SCLK_PIN)
    /* Set output pin state after block is disabled */
    emFile_SCB_SPI0_sclk_m_Write(emFile_SCB_SPI0_GET_SPI_SCLK_INACTIVE);

    /* Set GPIO to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SCLK_M_HSIOM_REG, emFile_SCB_SPI0_SCLK_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SCLK_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
#endif /* (emFile_SCB_SPI0_MISO_SDA_TX_PIN_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN)
    /* Set output pin state after block is disabled */
    emFile_SCB_SPI0_ss0_m_Write(emFile_SCB_SPI0_GET_SPI_SS0_INACTIVE);

    /* Set GPIO to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS0_M_HSIOM_REG, emFile_SCB_SPI0_SS0_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS0_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS0_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN)
    /* Set output pin state after block is disabled */
    emFile_SCB_SPI0_ss1_m_Write(emFile_SCB_SPI0_GET_SPI_SS1_INACTIVE);

    /* Set GPIO to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS1_M_HSIOM_REG, emFile_SCB_SPI0_SS1_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS1_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS1_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN)
    /* Set output pin state after block is disabled */
    emFile_SCB_SPI0_ss2_m_Write(emFile_SCB_SPI0_GET_SPI_SS2_INACTIVE);

    /* Set GPIO to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS2_M_HSIOM_REG, emFile_SCB_SPI0_SS2_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS2_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS2_PIN) */

#if (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN)
    /* Set output pin state after block is disabled */
    emFile_SCB_SPI0_ss3_m_Write(emFile_SCB_SPI0_GET_SPI_SS3_INACTIVE);

    /* Set GPIO to drive output pin */
    emFile_SCB_SPI0_SET_HSIOM_SEL(emFile_SCB_SPI0_SS3_M_HSIOM_REG, emFile_SCB_SPI0_SS3_M_HSIOM_MASK,
                                   emFile_SCB_SPI0_SS3_M_HSIOM_POS, emFile_SCB_SPI0_HSIOM_GPIO_SEL);
#endif /* (emFile_SCB_SPI0_SPI_MASTER_SS3_PIN) */

#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */
}


#if (emFile_SCB_SPI0_SPI_MASTER_CONST)
    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SetActiveSlaveSelect
    ********************************************************************************
    *
    * Summary:
    *  Selects one of the four slave select lines to be active during the transfer.
    *  After initialization the active slave select line is 0.
    *  The component should be in one of the following states to change the active
    *  slave select signal source correctly:
    *   - The component is disabled
    *   - The component has completed transfer (TX FIFO is empty and the
    *     SCB_INTR_MASTER_SPI_DONE status is set)
    *  This function does not check that these conditions are met.
    *  This function is only applicable to SPI Master mode of operation.
    *
    * Parameters:
    *  slaveSelect: slave select line which will be active while the following
    *               transfer.
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT0 - Slave select 0
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT1 - Slave select 1
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT2 - Slave select 2
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT3 - Slave select 3
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiSetActiveSlaveSelect(uint32 slaveSelect)
    {
        uint32 spiCtrl;

        spiCtrl = emFile_SCB_SPI0_SPI_CTRL_REG;

        spiCtrl &= (uint32) ~emFile_SCB_SPI0_SPI_CTRL_SLAVE_SELECT_MASK;
        spiCtrl |= (uint32)  emFile_SCB_SPI0_GET_SPI_CTRL_SS(slaveSelect);

        emFile_SCB_SPI0_SPI_CTRL_REG = spiCtrl;
    }
#endif /* (emFile_SCB_SPI0_SPI_MASTER_CONST) */


#if !(emFile_SCB_SPI0_CY_SCBIP_V0 || emFile_SCB_SPI0_CY_SCBIP_V1)
    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SpiSetSlaveSelectPolarity
    ********************************************************************************
    *
    * Summary:
    *  Sets active polarity for slave select line.
    *  The component should be in one of the following states to change the active
    *  slave select signal source correctly:
    *   - The component is disabled.
    *   - The component has completed transfer.
    *  This function does not check that these conditions are met.
    *
    * Parameters:
    *  slaveSelect: slave select line to change active polarity.
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT0 - Slave select 0
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT1 - Slave select 1
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT2 - Slave select 2
    *   emFile_SCB_SPI0_SPI_SLAVE_SELECT3 - Slave select 3
    *
    *  polarity: active polarity of slave select line.
    *   emFile_SCB_SPI0_SPI_SS_ACTIVE_LOW  - Slave select is active low
    *   emFile_SCB_SPI0_SPI_SS_ACTIVE_HIGH - Slave select is active high
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiSetSlaveSelectPolarity(uint32 slaveSelect, uint32 polarity)
    {
        uint32 ssPolarity;

        /* Get position of the polarity bit associated with slave select line */
        ssPolarity = emFile_SCB_SPI0_GET_SPI_CTRL_SSEL_POLARITY((uint32) 1u << slaveSelect);

        if (0u != polarity)
        {
            emFile_SCB_SPI0_SPI_CTRL_REG |= (uint32)  ssPolarity;
        }
        else
        {
            emFile_SCB_SPI0_SPI_CTRL_REG &= (uint32) ~ssPolarity;
        }
    }
#endif /* !(emFile_SCB_SPI0_CY_SCBIP_V0 || emFile_SCB_SPI0_CY_SCBIP_V1) */


#if(emFile_SCB_SPI0_SPI_WAKE_ENABLE_CONST)
    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SpiSaveConfig
    ********************************************************************************
    *
    * Summary:
    *  Clears INTR_SPI_EC.WAKE_UP and enables it. This interrupt
    *  source triggers when the master assigns the SS line and wakes up the device.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiSaveConfig(void)
    {
        emFile_SCB_SPI0_ClearSpiExtClkInterruptSource(emFile_SCB_SPI0_INTR_SPI_EC_WAKE_UP);
        emFile_SCB_SPI0_SetSpiExtClkInterruptMode(emFile_SCB_SPI0_INTR_SPI_EC_WAKE_UP);
    }


    /*******************************************************************************
    * Function Name: emFile_SCB_SPI0_SpiRestoreConfig
    ********************************************************************************
    *
    * Summary:
    *  Disables the INTR_SPI_EC.WAKE_UP interrupt source. After wakeup
    *  slave does not drive the MISO line and the master receives 0xFF.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void emFile_SCB_SPI0_SpiRestoreConfig(void)
    {
        emFile_SCB_SPI0_SetSpiExtClkInterruptMode(emFile_SCB_SPI0_NO_INTR_SOURCES);
    }
#endif /* (emFile_SCB_SPI0_SPI_WAKE_ENABLE_CONST) */


/* [] END OF FILE */
