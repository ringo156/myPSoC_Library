/*******************************************************************************
* File Name: emFile_SPI0_CS.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_emFile_SPI0_CS_H) /* Pins emFile_SPI0_CS_H */
#define CY_PINS_emFile_SPI0_CS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "emFile_SPI0_CS_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    emFile_SPI0_CS_Write(uint8 value) ;
void    emFile_SPI0_CS_SetDriveMode(uint8 mode) ;
uint8   emFile_SPI0_CS_ReadDataReg(void) ;
uint8   emFile_SPI0_CS_Read(void) ;
uint8   emFile_SPI0_CS_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define emFile_SPI0_CS_DRIVE_MODE_BITS        (3)
#define emFile_SPI0_CS_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - emFile_SPI0_CS_DRIVE_MODE_BITS))

#define emFile_SPI0_CS_DM_ALG_HIZ         (0x00u)
#define emFile_SPI0_CS_DM_DIG_HIZ         (0x01u)
#define emFile_SPI0_CS_DM_RES_UP          (0x02u)
#define emFile_SPI0_CS_DM_RES_DWN         (0x03u)
#define emFile_SPI0_CS_DM_OD_LO           (0x04u)
#define emFile_SPI0_CS_DM_OD_HI           (0x05u)
#define emFile_SPI0_CS_DM_STRONG          (0x06u)
#define emFile_SPI0_CS_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define emFile_SPI0_CS_MASK               emFile_SPI0_CS__MASK
#define emFile_SPI0_CS_SHIFT              emFile_SPI0_CS__SHIFT
#define emFile_SPI0_CS_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define emFile_SPI0_CS_PS                     (* (reg32 *) emFile_SPI0_CS__PS)
/* Port Configuration */
#define emFile_SPI0_CS_PC                     (* (reg32 *) emFile_SPI0_CS__PC)
/* Data Register */
#define emFile_SPI0_CS_DR                     (* (reg32 *) emFile_SPI0_CS__DR)
/* Input Buffer Disable Override */
#define emFile_SPI0_CS_INP_DIS                (* (reg32 *) emFile_SPI0_CS__PC2)


#if defined(emFile_SPI0_CS__INTSTAT)  /* Interrupt Registers */

    #define emFile_SPI0_CS_INTSTAT                (* (reg32 *) emFile_SPI0_CS__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define emFile_SPI0_CS_DRIVE_MODE_SHIFT       (0x00u)
#define emFile_SPI0_CS_DRIVE_MODE_MASK        (0x07u << emFile_SPI0_CS_DRIVE_MODE_SHIFT)


#endif /* End Pins emFile_SPI0_CS_H */


/* [] END OF FILE */
