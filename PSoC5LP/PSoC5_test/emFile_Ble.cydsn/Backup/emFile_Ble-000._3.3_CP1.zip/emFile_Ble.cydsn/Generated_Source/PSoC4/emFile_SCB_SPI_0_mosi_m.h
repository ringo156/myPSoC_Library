/*******************************************************************************
* File Name: emFile_SCB_SPI_0_mosi_m.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_emFile_SCB_SPI_0_mosi_m_H) /* Pins emFile_SCB_SPI_0_mosi_m_H */
#define CY_PINS_emFile_SCB_SPI_0_mosi_m_H

#include "cytypes.h"
#include "cyfitter.h"
#include "emFile_SCB_SPI_0_mosi_m_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    emFile_SCB_SPI_0_mosi_m_Write(uint8 value) ;
void    emFile_SCB_SPI_0_mosi_m_SetDriveMode(uint8 mode) ;
uint8   emFile_SCB_SPI_0_mosi_m_ReadDataReg(void) ;
uint8   emFile_SCB_SPI_0_mosi_m_Read(void) ;
uint8   emFile_SCB_SPI_0_mosi_m_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_BITS        (3)
#define emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_BITS))

#define emFile_SCB_SPI_0_mosi_m_DM_ALG_HIZ         (0x00u)
#define emFile_SCB_SPI_0_mosi_m_DM_DIG_HIZ         (0x01u)
#define emFile_SCB_SPI_0_mosi_m_DM_RES_UP          (0x02u)
#define emFile_SCB_SPI_0_mosi_m_DM_RES_DWN         (0x03u)
#define emFile_SCB_SPI_0_mosi_m_DM_OD_LO           (0x04u)
#define emFile_SCB_SPI_0_mosi_m_DM_OD_HI           (0x05u)
#define emFile_SCB_SPI_0_mosi_m_DM_STRONG          (0x06u)
#define emFile_SCB_SPI_0_mosi_m_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define emFile_SCB_SPI_0_mosi_m_MASK               emFile_SCB_SPI_0_mosi_m__MASK
#define emFile_SCB_SPI_0_mosi_m_SHIFT              emFile_SCB_SPI_0_mosi_m__SHIFT
#define emFile_SCB_SPI_0_mosi_m_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define emFile_SCB_SPI_0_mosi_m_PS                     (* (reg32 *) emFile_SCB_SPI_0_mosi_m__PS)
/* Port Configuration */
#define emFile_SCB_SPI_0_mosi_m_PC                     (* (reg32 *) emFile_SCB_SPI_0_mosi_m__PC)
/* Data Register */
#define emFile_SCB_SPI_0_mosi_m_DR                     (* (reg32 *) emFile_SCB_SPI_0_mosi_m__DR)
/* Input Buffer Disable Override */
#define emFile_SCB_SPI_0_mosi_m_INP_DIS                (* (reg32 *) emFile_SCB_SPI_0_mosi_m__PC2)


#if defined(emFile_SCB_SPI_0_mosi_m__INTSTAT)  /* Interrupt Registers */

    #define emFile_SCB_SPI_0_mosi_m_INTSTAT                (* (reg32 *) emFile_SCB_SPI_0_mosi_m__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_SHIFT       (0x00u)
#define emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_MASK        (0x07u << emFile_SCB_SPI_0_mosi_m_DRIVE_MODE_SHIFT)


#endif /* End Pins emFile_SCB_SPI_0_mosi_m_H */


/* [] END OF FILE */
