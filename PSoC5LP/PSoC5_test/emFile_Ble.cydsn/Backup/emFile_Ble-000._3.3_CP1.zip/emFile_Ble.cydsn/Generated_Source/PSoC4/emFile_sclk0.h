/*******************************************************************************
* File Name: emFile_sclk0.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_emFile_sclk0_H) /* Pins emFile_sclk0_H */
#define CY_PINS_emFile_sclk0_H

#include "cytypes.h"
#include "cyfitter.h"
#include "emFile_sclk0_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    emFile_sclk0_Write(uint8 value) ;
void    emFile_sclk0_SetDriveMode(uint8 mode) ;
uint8   emFile_sclk0_ReadDataReg(void) ;
uint8   emFile_sclk0_Read(void) ;
uint8   emFile_sclk0_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define emFile_sclk0_DRIVE_MODE_BITS        (3)
#define emFile_sclk0_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - emFile_sclk0_DRIVE_MODE_BITS))

#define emFile_sclk0_DM_ALG_HIZ         (0x00u)
#define emFile_sclk0_DM_DIG_HIZ         (0x01u)
#define emFile_sclk0_DM_RES_UP          (0x02u)
#define emFile_sclk0_DM_RES_DWN         (0x03u)
#define emFile_sclk0_DM_OD_LO           (0x04u)
#define emFile_sclk0_DM_OD_HI           (0x05u)
#define emFile_sclk0_DM_STRONG          (0x06u)
#define emFile_sclk0_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define emFile_sclk0_MASK               emFile_sclk0__MASK
#define emFile_sclk0_SHIFT              emFile_sclk0__SHIFT
#define emFile_sclk0_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define emFile_sclk0_PS                     (* (reg32 *) emFile_sclk0__PS)
/* Port Configuration */
#define emFile_sclk0_PC                     (* (reg32 *) emFile_sclk0__PC)
/* Data Register */
#define emFile_sclk0_DR                     (* (reg32 *) emFile_sclk0__DR)
/* Input Buffer Disable Override */
#define emFile_sclk0_INP_DIS                (* (reg32 *) emFile_sclk0__PC2)


#if defined(emFile_sclk0__INTSTAT)  /* Interrupt Registers */

    #define emFile_sclk0_INTSTAT                (* (reg32 *) emFile_sclk0__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define emFile_sclk0_DRIVE_MODE_SHIFT       (0x00u)
#define emFile_sclk0_DRIVE_MODE_MASK        (0x07u << emFile_sclk0_DRIVE_MODE_SHIFT)


#endif /* End Pins emFile_sclk0_H */


/* [] END OF FILE */
