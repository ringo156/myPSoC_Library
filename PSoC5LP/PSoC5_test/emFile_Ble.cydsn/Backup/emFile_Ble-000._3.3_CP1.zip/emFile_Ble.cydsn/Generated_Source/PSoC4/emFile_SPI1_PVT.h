/*******************************************************************************
* File Name: .h
* Version 3.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_emFile_SPI1_H)
#define CY_SCB_PVT_emFile_SPI1_H

#include "emFile_SPI1.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define emFile_SPI1_SetI2CExtClkInterruptMode(interruptMask) emFile_SPI1_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define emFile_SPI1_ClearI2CExtClkInterruptSource(interruptMask) emFile_SPI1_CLEAR_INTR_I2C_EC(interruptMask)
#define emFile_SPI1_GetI2CExtClkInterruptSource()                (emFile_SPI1_INTR_I2C_EC_REG)
#define emFile_SPI1_GetI2CExtClkInterruptMode()                  (emFile_SPI1_INTR_I2C_EC_MASK_REG)
#define emFile_SPI1_GetI2CExtClkInterruptSourceMasked()          (emFile_SPI1_INTR_I2C_EC_MASKED_REG)

#if (!emFile_SPI1_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define emFile_SPI1_SetSpiExtClkInterruptMode(interruptMask) \
                                                                emFile_SPI1_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define emFile_SPI1_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                emFile_SPI1_CLEAR_INTR_SPI_EC(interruptMask)
    #define emFile_SPI1_GetExtSpiClkInterruptSource()                 (emFile_SPI1_INTR_SPI_EC_REG)
    #define emFile_SPI1_GetExtSpiClkInterruptMode()                   (emFile_SPI1_INTR_SPI_EC_MASK_REG)
    #define emFile_SPI1_GetExtSpiClkInterruptSourceMasked()           (emFile_SPI1_INTR_SPI_EC_MASKED_REG)
#endif /* (!emFile_SPI1_CY_SCBIP_V1) */

#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void emFile_SPI1_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (emFile_SPI1_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_emFile_SPI1_CUSTOM_INTR_HANDLER)
    extern cyisraddress emFile_SPI1_customIntrHandler;
#endif /* !defined (CY_REMOVE_emFile_SPI1_CUSTOM_INTR_HANDLER) */
#endif /* (emFile_SPI1_SCB_IRQ_INTERNAL) */

extern emFile_SPI1_BACKUP_STRUCT emFile_SPI1_backup;

#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 emFile_SPI1_scbMode;
    extern uint8 emFile_SPI1_scbEnableWake;
    extern uint8 emFile_SPI1_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 emFile_SPI1_mode;
    extern uint8 emFile_SPI1_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * emFile_SPI1_rxBuffer;
    extern uint8   emFile_SPI1_rxDataBits;
    extern uint32  emFile_SPI1_rxBufferSize;

    extern volatile uint8 * emFile_SPI1_txBuffer;
    extern uint8   emFile_SPI1_txDataBits;
    extern uint32  emFile_SPI1_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 emFile_SPI1_numberOfAddr;
    extern uint8 emFile_SPI1_subAddrSize;
#endif /* (emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*        Conditional Macro
****************************************/

#if(emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define emFile_SPI1_SCB_MODE_I2C_RUNTM_CFG     (emFile_SPI1_SCB_MODE_I2C      == emFile_SPI1_scbMode)
    #define emFile_SPI1_SCB_MODE_SPI_RUNTM_CFG     (emFile_SPI1_SCB_MODE_SPI      == emFile_SPI1_scbMode)
    #define emFile_SPI1_SCB_MODE_UART_RUNTM_CFG    (emFile_SPI1_SCB_MODE_UART     == emFile_SPI1_scbMode)
    #define emFile_SPI1_SCB_MODE_EZI2C_RUNTM_CFG   (emFile_SPI1_SCB_MODE_EZI2C    == emFile_SPI1_scbMode)
    #define emFile_SPI1_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (emFile_SPI1_SCB_MODE_UNCONFIG == emFile_SPI1_scbMode)

    /* Defines wakeup enable */
    #define emFile_SPI1_SCB_WAKE_ENABLE_CHECK       (0u != emFile_SPI1_scbEnableWake)
#endif /* (emFile_SPI1_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!emFile_SPI1_CY_SCBIP_V1)
    #define emFile_SPI1_SCB_PINS_NUMBER    (7u)
#else
    #define emFile_SPI1_SCB_PINS_NUMBER    (2u)
#endif /* (!emFile_SPI1_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_emFile_SPI1_H) */


/* [] END OF FILE */
