/*******************************************************************************
* File Name: .h
* Version 3.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_emFile_SCB_SPI0_H)
#define CY_SCB_PVT_emFile_SCB_SPI0_H

#include "emFile_SCB_SPI0.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define emFile_SCB_SPI0_SetI2CExtClkInterruptMode(interruptMask) emFile_SCB_SPI0_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define emFile_SCB_SPI0_ClearI2CExtClkInterruptSource(interruptMask) emFile_SCB_SPI0_CLEAR_INTR_I2C_EC(interruptMask)
#define emFile_SCB_SPI0_GetI2CExtClkInterruptSource()                (emFile_SCB_SPI0_INTR_I2C_EC_REG)
#define emFile_SCB_SPI0_GetI2CExtClkInterruptMode()                  (emFile_SCB_SPI0_INTR_I2C_EC_MASK_REG)
#define emFile_SCB_SPI0_GetI2CExtClkInterruptSourceMasked()          (emFile_SCB_SPI0_INTR_I2C_EC_MASKED_REG)

#if (!emFile_SCB_SPI0_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define emFile_SCB_SPI0_SetSpiExtClkInterruptMode(interruptMask) \
                                                                emFile_SCB_SPI0_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define emFile_SCB_SPI0_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                emFile_SCB_SPI0_CLEAR_INTR_SPI_EC(interruptMask)
    #define emFile_SCB_SPI0_GetExtSpiClkInterruptSource()                 (emFile_SCB_SPI0_INTR_SPI_EC_REG)
    #define emFile_SCB_SPI0_GetExtSpiClkInterruptMode()                   (emFile_SCB_SPI0_INTR_SPI_EC_MASK_REG)
    #define emFile_SCB_SPI0_GetExtSpiClkInterruptSourceMasked()           (emFile_SCB_SPI0_INTR_SPI_EC_MASKED_REG)
#endif /* (!emFile_SCB_SPI0_CY_SCBIP_V1) */

#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void emFile_SCB_SPI0_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (emFile_SCB_SPI0_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_emFile_SCB_SPI0_CUSTOM_INTR_HANDLER)
    extern cyisraddress emFile_SCB_SPI0_customIntrHandler;
#endif /* !defined (CY_REMOVE_emFile_SCB_SPI0_CUSTOM_INTR_HANDLER) */
#endif /* (emFile_SCB_SPI0_SCB_IRQ_INTERNAL) */

extern emFile_SCB_SPI0_BACKUP_STRUCT emFile_SCB_SPI0_backup;

#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 emFile_SCB_SPI0_scbMode;
    extern uint8 emFile_SCB_SPI0_scbEnableWake;
    extern uint8 emFile_SCB_SPI0_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 emFile_SCB_SPI0_mode;
    extern uint8 emFile_SCB_SPI0_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * emFile_SCB_SPI0_rxBuffer;
    extern uint8   emFile_SCB_SPI0_rxDataBits;
    extern uint32  emFile_SCB_SPI0_rxBufferSize;

    extern volatile uint8 * emFile_SCB_SPI0_txBuffer;
    extern uint8   emFile_SCB_SPI0_txDataBits;
    extern uint32  emFile_SCB_SPI0_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 emFile_SCB_SPI0_numberOfAddr;
    extern uint8 emFile_SCB_SPI0_subAddrSize;
#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*        Conditional Macro
****************************************/

#if(emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define emFile_SCB_SPI0_SCB_MODE_I2C_RUNTM_CFG     (emFile_SCB_SPI0_SCB_MODE_I2C      == emFile_SCB_SPI0_scbMode)
    #define emFile_SCB_SPI0_SCB_MODE_SPI_RUNTM_CFG     (emFile_SCB_SPI0_SCB_MODE_SPI      == emFile_SCB_SPI0_scbMode)
    #define emFile_SCB_SPI0_SCB_MODE_UART_RUNTM_CFG    (emFile_SCB_SPI0_SCB_MODE_UART     == emFile_SCB_SPI0_scbMode)
    #define emFile_SCB_SPI0_SCB_MODE_EZI2C_RUNTM_CFG   (emFile_SCB_SPI0_SCB_MODE_EZI2C    == emFile_SCB_SPI0_scbMode)
    #define emFile_SCB_SPI0_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (emFile_SCB_SPI0_SCB_MODE_UNCONFIG == emFile_SCB_SPI0_scbMode)

    /* Defines wakeup enable */
    #define emFile_SCB_SPI0_SCB_WAKE_ENABLE_CHECK       (0u != emFile_SCB_SPI0_scbEnableWake)
#endif /* (emFile_SCB_SPI0_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!emFile_SCB_SPI0_CY_SCBIP_V1)
    #define emFile_SCB_SPI0_SCB_PINS_NUMBER    (7u)
#else
    #define emFile_SCB_SPI0_SCB_PINS_NUMBER    (2u)
#endif /* (!emFile_SCB_SPI0_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_emFile_SCB_SPI0_H) */


/* [] END OF FILE */
