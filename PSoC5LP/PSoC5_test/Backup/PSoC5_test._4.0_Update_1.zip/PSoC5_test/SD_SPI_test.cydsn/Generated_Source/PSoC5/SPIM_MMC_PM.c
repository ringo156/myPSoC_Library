/*******************************************************************************
* File Name: SPIM_MMC_PM.c
* Version 2.50
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIM_MMC_PVT.h"

static SPIM_MMC_BACKUP_STRUCT SPIM_MMC_backup =
{
    SPIM_MMC_DISABLED,
    SPIM_MMC_BITCTR_INIT,
};


/*******************************************************************************
* Function Name: SPIM_MMC_SaveConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIM_MMC_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIM_MMC_RestoreConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIM_MMC_RestoreConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIM_MMC_Sleep
********************************************************************************
*
* Summary:
*  Prepare SPIM Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIM_MMC_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIM_MMC_Sleep(void) 
{
    /* Save components enable state */
    SPIM_MMC_backup.enableState = ((uint8) SPIM_MMC_IS_ENABLED);

    SPIM_MMC_Stop();
}


/*******************************************************************************
* Function Name: SPIM_MMC_Wakeup
********************************************************************************
*
* Summary:
*  Prepare SPIM Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIM_MMC_backup - used when non-retention registers are restored.
*  SPIM_MMC_txBufferWrite - modified every function call - resets to
*  zero.
*  SPIM_MMC_txBufferRead - modified every function call - resets to
*  zero.
*  SPIM_MMC_rxBufferWrite - modified every function call - resets to
*  zero.
*  SPIM_MMC_rxBufferRead - modified every function call - resets to
*  zero.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIM_MMC_Wakeup(void) 
{
    #if(SPIM_MMC_RX_SOFTWARE_BUF_ENABLED)
        SPIM_MMC_rxBufferFull  = 0u;
        SPIM_MMC_rxBufferRead  = 0u;
        SPIM_MMC_rxBufferWrite = 0u;
    #endif /* (SPIM_MMC_RX_SOFTWARE_BUF_ENABLED) */

    #if(SPIM_MMC_TX_SOFTWARE_BUF_ENABLED)
        SPIM_MMC_txBufferFull  = 0u;
        SPIM_MMC_txBufferRead  = 0u;
        SPIM_MMC_txBufferWrite = 0u;
    #endif /* (SPIM_MMC_TX_SOFTWARE_BUF_ENABLED) */

    /* Clear any data from the RX and TX FIFO */
    SPIM_MMC_ClearFIFO();

    /* Restore components block enable state */
    if(0u != SPIM_MMC_backup.enableState)
    {
        SPIM_MMC_Enable();
    }
}


/* [] END OF FILE */
