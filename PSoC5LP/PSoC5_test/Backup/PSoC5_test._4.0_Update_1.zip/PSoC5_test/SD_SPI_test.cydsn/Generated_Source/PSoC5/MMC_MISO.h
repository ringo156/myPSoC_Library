/*******************************************************************************
* File Name: MMC_MISO.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MMC_MISO_H) /* Pins MMC_MISO_H */
#define CY_PINS_MMC_MISO_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "MMC_MISO_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 MMC_MISO__PORT == 15 && ((MMC_MISO__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    MMC_MISO_Write(uint8 value);
void    MMC_MISO_SetDriveMode(uint8 mode);
uint8   MMC_MISO_ReadDataReg(void);
uint8   MMC_MISO_Read(void);
void    MMC_MISO_SetInterruptMode(uint16 position, uint16 mode);
uint8   MMC_MISO_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the MMC_MISO_SetDriveMode() function.
     *  @{
     */
        #define MMC_MISO_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define MMC_MISO_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define MMC_MISO_DM_RES_UP          PIN_DM_RES_UP
        #define MMC_MISO_DM_RES_DWN         PIN_DM_RES_DWN
        #define MMC_MISO_DM_OD_LO           PIN_DM_OD_LO
        #define MMC_MISO_DM_OD_HI           PIN_DM_OD_HI
        #define MMC_MISO_DM_STRONG          PIN_DM_STRONG
        #define MMC_MISO_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define MMC_MISO_MASK               MMC_MISO__MASK
#define MMC_MISO_SHIFT              MMC_MISO__SHIFT
#define MMC_MISO_WIDTH              1u

/* Interrupt constants */
#if defined(MMC_MISO__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in MMC_MISO_SetInterruptMode() function.
     *  @{
     */
        #define MMC_MISO_INTR_NONE      (uint16)(0x0000u)
        #define MMC_MISO_INTR_RISING    (uint16)(0x0001u)
        #define MMC_MISO_INTR_FALLING   (uint16)(0x0002u)
        #define MMC_MISO_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define MMC_MISO_INTR_MASK      (0x01u) 
#endif /* (MMC_MISO__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define MMC_MISO_PS                     (* (reg8 *) MMC_MISO__PS)
/* Data Register */
#define MMC_MISO_DR                     (* (reg8 *) MMC_MISO__DR)
/* Port Number */
#define MMC_MISO_PRT_NUM                (* (reg8 *) MMC_MISO__PRT) 
/* Connect to Analog Globals */                                                  
#define MMC_MISO_AG                     (* (reg8 *) MMC_MISO__AG)                       
/* Analog MUX bux enable */
#define MMC_MISO_AMUX                   (* (reg8 *) MMC_MISO__AMUX) 
/* Bidirectional Enable */                                                        
#define MMC_MISO_BIE                    (* (reg8 *) MMC_MISO__BIE)
/* Bit-mask for Aliased Register Access */
#define MMC_MISO_BIT_MASK               (* (reg8 *) MMC_MISO__BIT_MASK)
/* Bypass Enable */
#define MMC_MISO_BYP                    (* (reg8 *) MMC_MISO__BYP)
/* Port wide control signals */                                                   
#define MMC_MISO_CTL                    (* (reg8 *) MMC_MISO__CTL)
/* Drive Modes */
#define MMC_MISO_DM0                    (* (reg8 *) MMC_MISO__DM0) 
#define MMC_MISO_DM1                    (* (reg8 *) MMC_MISO__DM1)
#define MMC_MISO_DM2                    (* (reg8 *) MMC_MISO__DM2) 
/* Input Buffer Disable Override */
#define MMC_MISO_INP_DIS                (* (reg8 *) MMC_MISO__INP_DIS)
/* LCD Common or Segment Drive */
#define MMC_MISO_LCD_COM_SEG            (* (reg8 *) MMC_MISO__LCD_COM_SEG)
/* Enable Segment LCD */
#define MMC_MISO_LCD_EN                 (* (reg8 *) MMC_MISO__LCD_EN)
/* Slew Rate Control */
#define MMC_MISO_SLW                    (* (reg8 *) MMC_MISO__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define MMC_MISO_PRTDSI__CAPS_SEL       (* (reg8 *) MMC_MISO__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define MMC_MISO_PRTDSI__DBL_SYNC_IN    (* (reg8 *) MMC_MISO__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define MMC_MISO_PRTDSI__OE_SEL0        (* (reg8 *) MMC_MISO__PRTDSI__OE_SEL0) 
#define MMC_MISO_PRTDSI__OE_SEL1        (* (reg8 *) MMC_MISO__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define MMC_MISO_PRTDSI__OUT_SEL0       (* (reg8 *) MMC_MISO__PRTDSI__OUT_SEL0) 
#define MMC_MISO_PRTDSI__OUT_SEL1       (* (reg8 *) MMC_MISO__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define MMC_MISO_PRTDSI__SYNC_OUT       (* (reg8 *) MMC_MISO__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(MMC_MISO__SIO_CFG)
    #define MMC_MISO_SIO_HYST_EN        (* (reg8 *) MMC_MISO__SIO_HYST_EN)
    #define MMC_MISO_SIO_REG_HIFREQ     (* (reg8 *) MMC_MISO__SIO_REG_HIFREQ)
    #define MMC_MISO_SIO_CFG            (* (reg8 *) MMC_MISO__SIO_CFG)
    #define MMC_MISO_SIO_DIFF           (* (reg8 *) MMC_MISO__SIO_DIFF)
#endif /* (MMC_MISO__SIO_CFG) */

/* Interrupt Registers */
#if defined(MMC_MISO__INTSTAT)
    #define MMC_MISO_INTSTAT            (* (reg8 *) MMC_MISO__INTSTAT)
    #define MMC_MISO_SNAP               (* (reg8 *) MMC_MISO__SNAP)
    
	#define MMC_MISO_0_INTTYPE_REG 		(* (reg8 *) MMC_MISO__0__INTTYPE)
#endif /* (MMC_MISO__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_MMC_MISO_H */


/* [] END OF FILE */
